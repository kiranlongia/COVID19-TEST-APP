package com.example.covidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class countryDetailActivity extends AppCompatActivity {
    TextView allcases,deaths,activecases,recovered,countryTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_detail);
allcases=findViewById(R.id.tvshowallcases);
deaths=findViewById(R.id.tvShowDeaths);
activecases=findViewById(R.id.tvShowActive);
recovered=findViewById(R.id.tvShowRecovered);
countryTitle=findViewById(R.id.tvTitle);
        countryTitle.setText(MainActivity.selectedCountry);
        allcases.setText(String.valueOf(MainActivity.selectedAllcases));
        activecases.setText(String.valueOf(MainActivity.selectedActiveCases));
        deaths.setText(String.valueOf(MainActivity.selecteddeath));
        recovered.setText(String.valueOf(MainActivity.selectedRecovered));
    }
}
