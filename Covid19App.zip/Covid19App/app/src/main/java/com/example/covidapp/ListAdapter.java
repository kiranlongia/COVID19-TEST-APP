package com.example.covidapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends BaseAdapter {
    private ArrayList<Cases> countryData;
    private LayoutInflater layoutInflater;

    public ListAdapter(Context context, ArrayList<Cases> countryData) {
        this.countryData = countryData;
        layoutInflater= LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        return countryData.size();
    }

    @Override
    public Object getItem(int i) {
        return countryData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if( view==null){

            view= layoutInflater.inflate(R.layout.list_row,null);
            holder=new ViewHolder();
            holder.countryTv=view.findViewById(R.id.tvCountry);
            holder.allcasesTv=view.findViewById(R.id.tvAllcases);
           // holder.img=view.findViewById(R.id.imageView);
            view.setTag(holder);
        }
        else
            holder=(ViewHolder) view.getTag();
        holder.countryTv.setText(countryData.get(i).getCountry());
        holder.allcasesTv.setText(String.valueOf(countryData.get(i).getAllCases()));


        return view;
    }
    static class ViewHolder{
        private TextView countryTv;
        private  TextView allcasesTv;

    }

    }

