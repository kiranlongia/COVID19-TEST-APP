package com.example.covidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

import static android.widget.AdapterView.*;

public class MainActivity extends AppCompatActivity implements OnItemSelectedListener, OnItemClickListener {
    Spinner sp;
    ListView lv;

    ArrayList<Cases> country = new ArrayList<Cases>();
    String continents[]={"North America","South America","Europe","Asia"};

    ArrayList <Cases> selectedcont=new ArrayList<Cases>();//arraylist for spinner formation

    public static String selectedCountry;
    public static int selectedAllcases;
    public static int selecteddeath;
    public static int selectedActiveCases;
    public static int selectedRecovered;



    public void fillData(){
        country.add(new Cases("North America","Canada",40190,2005,24230,13789));
        country.add(new Cases("North America","USA",848779,47230,717456,84723));
        country.add(new Cases("North America","Mexico",10592,970,6947,2627));
        country.add(new Cases("South America","Brazil",40190,2005,24230,13789));
        country.add(new Cases("South America","Peru",40190,2005,24230,13789));
        country.add(new Cases("Europe","UK",133456,18100,115051,22567));
        country.add(new Cases("Europe","France",159315,21340,79880,40657));
        country.add(new Cases("Europe","Germany",150234,5315,99400,45560));
        country.add(new Cases("Europe","Spain",208455,21717,107345,85912));
        country.add(new Cases("Europe","Italy",187652,25085,107668,545376));
        country.add(new Cases("Asia","China",82345,4632,959,77207));
        country.add(new Cases("Asia","Japan",11950,299,10227,1424));
        country.add(new Cases("Asia","India",21370,681,16319,4370));
        country.add(new Cases("Asia","South Korea",10702,240,2051,8233));

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv=findViewById(R.id.lvCountry);
       fillData();

        //initilize the spinner
        sp=findViewById(R.id.spContinent);
        //create the adapter for the spinner
        ArrayAdapter aa=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,continents);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);//fill the spinner from the adapter

  sp.setOnItemSelectedListener(this);
  lv.setOnItemSelectedListener(this);
  lv.setOnItemClickListener(this);

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        if(adapterView.getId()==R.id.spContinent) {
            selectedcont.clear();//selectedcont is array list
            String continent = continents[i];//continent is an array of continents(North america,south america,europe,asia)
            for (int j = 0; j < country.size(); j++)
                if (country.get(j).getContinent().equals(continent))
                    selectedcont.add(country.get(j));
            lv.setAdapter(new ListAdapter(this, selectedcont));
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.lvCountry){
            selectedCountry=selectedcont.get(i).getCountry();
            selectedAllcases=selectedcont.get(i).getAllCases();
            selectedActiveCases=selectedcont.get(i).activeCases;
            selecteddeath=selectedcont.get(i).death;
            selectedRecovered=selectedcont.get(i).recovered;
            Intent intent = new Intent(this,countryDetailActivity.class);
            startActivity(intent);
        }
    }
}
